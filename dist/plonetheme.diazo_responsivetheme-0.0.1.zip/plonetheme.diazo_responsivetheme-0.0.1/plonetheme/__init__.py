from pkg_resources import declare_namespace

declare_namespace(__name__)
