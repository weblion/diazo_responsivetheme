jq(document).ready(function() {
       jq('a#portal-logo').addClass('cell width-1:4 position-0');
       jq('#portal-personaltools-wrapper').addClass('cell position-13 width-3');
 }); 